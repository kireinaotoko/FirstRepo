package exceptions;

public class ThrowException {
	public static void main(String[] args) throws Exception {
		
		throw new Exception("Something is wrong");
		
	}
}
