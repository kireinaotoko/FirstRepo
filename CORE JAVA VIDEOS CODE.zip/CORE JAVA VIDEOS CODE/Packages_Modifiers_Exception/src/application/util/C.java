package application.util;

import testcases.A;

public class C extends A{
	
	public void init() {
		x=1;
		//y=2;
		//z=3;
		p=4;
	}
}
