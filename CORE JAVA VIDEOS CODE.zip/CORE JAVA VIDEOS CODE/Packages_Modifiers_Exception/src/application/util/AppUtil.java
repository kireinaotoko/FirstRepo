package application.util;



public  class AppUtil {
	
	public String filePath="D:/xyz.txt";
	
	public void print(String message) {
		System.out.println(message);
	}

}
