package application.util;

public interface Application {

	String name="hello"; // public , static , final
}
