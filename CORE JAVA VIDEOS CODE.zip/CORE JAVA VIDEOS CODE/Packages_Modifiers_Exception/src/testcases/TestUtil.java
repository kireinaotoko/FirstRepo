package testcases;

public class TestUtil {
	
	
	String name;
	private int count;//0
	protected int i;
	
	
	void printName() {
		System.out.println(name);
	}
	
	public void increaseCount() {
		count++;
		System.out.println(count);
	}

}
