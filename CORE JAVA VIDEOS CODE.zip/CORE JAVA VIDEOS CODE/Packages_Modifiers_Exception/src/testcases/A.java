package testcases;

public class A {

	public int x;
	int y;
	//private int z;
	protected int p; 
	
}
