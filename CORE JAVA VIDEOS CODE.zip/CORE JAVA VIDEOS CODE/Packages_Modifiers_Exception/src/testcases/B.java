package testcases;

public class B extends A{

	
	public void init() {
		x=1;
		y=2;
		//z=3;
		p=4;
	}
}
