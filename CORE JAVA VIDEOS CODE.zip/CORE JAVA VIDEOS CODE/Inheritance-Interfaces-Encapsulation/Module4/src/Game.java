
public class Game {
	
	String name;
	int duration;
	
	public void start(){
		System.out.println("starting game "+name);
	}
	
	public void end(){
		System.out.println("ending game");
	}

}
