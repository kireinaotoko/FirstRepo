package temp;

public class Test {

	public static void main(String arg[]) {
		HondaCar c = new HondaCar(100);
		System.out.println(c.fuelcapacity);
		
	}
}
