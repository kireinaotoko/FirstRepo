
public interface Bank {
	
	public void transfermoney();
	public void debit();
	public void credit();

}
