package reflections;

public class Operations {
		
	public void add(int a, int b) {
		int sum = a+b;
		System.out.println(sum);
	}
	
	
	public void diff(int a, int b) {
		int diff = a-b;
		System.out.println(diff);
	}
	
	public void mult(int a, int b) {
		int res = a*b;
		System.out.println(res);
	}
	
	
	public void div(int a, int b) {
		int res = a/b;
		System.out.println(res);
	}


}
