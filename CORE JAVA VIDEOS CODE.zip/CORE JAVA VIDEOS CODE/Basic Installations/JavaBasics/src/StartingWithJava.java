
public class StartingWithJava {

	public static void main(String[] args) {
		
		System.out.println("Learning Java");
		System.out.println("From Whizdom Trainings");
		System.out.print(" and practicing");
		System.out.println(" I am good");
		System.out.println("1231237");
		System.out.println(19289812);
		
		
		
	}

}
