
public class Statements {

	public static void main(String[] args) {
		int a=200;
		int b=200;
		
		if(a>b) {
			System.out.println(" A is greater "+a);
		}else if(a<b){
			System.out.println("B is greater "+b);
		}else {
			System.out.println("both equal");
		}

	}

}
