
public class Datatypes {
// control  -default
	// F5 - line by line
	// F8 - normally
	public static void main(String[] args) {
		System.out.println("Learning dataypes");
		
		byte b=127;
		short s=400;
		int i=100;// 99%ncncn
		long l=1000;
		
		i =200;
		
		System.out.println("i");
		System.out.println(i);
		
		float f=100.45f;
		double d=300; //99%
		System.out.println(d);
		char c = 'g';
		boolean bool=true; // true or false
		System.out.println(7>12);
		bool=15>11;
		
		
		// concatination operator
		System.out.println("Value of i is "+i);
		System.out.println("10 added to i "+ i+10);
		System.out.println(i+10);
		System.out.println(i+10+" is the result of addition");
		System.out.println("10 added to i "+ (i+10));
		
		
		String str = "Hello there";
		System.out.println(str);
	
	}

}
