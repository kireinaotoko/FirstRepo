
public class WhileLoops {
	public static void main(String[] args) {

		int i=100;
		while(i>=1) {
			System.out.println(i);
			if(i==95)
				break;
			i--;
		}
		
		boolean friendListLoaded=false;
		while(!friendListLoaded) {
			// load - scroll down once
			// check
			//if(loaded)
				//friendListLoaded=true;
		}
	}
}
