
public class Operators {

	public static void main(String[] args) {
		// > < >= <= == !=
		// &,&&,|,||
		System.out.println(6>=6);
		int a=10;
		int b=6;
		
		if(a!=b) {
			System.out.println("Both are not equal");
		}
		
		System.out.println(a%b);

	}

}
