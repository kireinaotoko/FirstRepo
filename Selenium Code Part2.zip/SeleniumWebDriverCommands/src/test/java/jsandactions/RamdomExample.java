package jsandactions;

import java.util.Random;

public class RamdomExample {

	public static void main(String[] args) {
		Random r = new Random();
		System.out.println(r.nextInt());
		System.out.println(r.nextInt(100));//0-99

	}

}
