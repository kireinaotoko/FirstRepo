package multipleobjectextraction;

import org.testng.annotations.Test;

public class CnnHeaderLinkTesting {
	
	@Test
	public void cnnHeaderLinks() {
		// extract all links - list
		/*
		list{
		// get 1 link
		   Check the presence, visibility
		   check response code - 200
		   click
		   check - next page OK
		   go back
		}
		
		
		*/
	}

}
