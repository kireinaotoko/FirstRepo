package pages;

import org.testng.Assert;

public class EnterPasswordPage extends BasePage{

	
	public void validateTitle(String expectedTitle) {
		//Assert.assertEquals(driver.getTitle(), expectedTitle);
	}
}
