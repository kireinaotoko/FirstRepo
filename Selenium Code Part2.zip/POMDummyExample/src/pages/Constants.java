package pages;

public class Constants {
	
	public static final String LOGIN_LINK="a.zh-login";
	public static final String LOGIN_ID = "login_id";
	public static final String NEXT_BUTTON = "button#nextbtn > span";

}
