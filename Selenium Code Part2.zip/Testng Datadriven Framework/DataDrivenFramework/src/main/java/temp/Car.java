package temp;

public class Car {
	
	public void start() {
		System.out.println("Car starting");
	}
	
	public void refuel() {
		System.out.println("Car Refueling");
	}

}
