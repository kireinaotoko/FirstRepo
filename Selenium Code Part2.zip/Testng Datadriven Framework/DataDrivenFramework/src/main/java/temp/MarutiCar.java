package temp;

public class MarutiCar extends Car{
	
	public void musicSystem() {
		
	}

	
}
