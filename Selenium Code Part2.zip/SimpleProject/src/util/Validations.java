package util;

import org.openqa.selenium.WebDriver;

import testcases.TestBase;

public class Validations {
	
	public void validateTitle(String expectedTitle) {
		TestBase.driver.getTitle();
	}
	
	
	//10 - valText, valPageLoad

}
