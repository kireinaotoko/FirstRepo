package zoho.teststeps.data;

public class LeadData {
	public String firstName;
	public String lastName;
	public String email;
	public String company;

	public LeadData(String firstName, String lastName, String email, String company) {
	
		this.firstName=firstName;
		this.lastName=lastName;
		this.email=email;
		this.company=company;
		
	}

}
