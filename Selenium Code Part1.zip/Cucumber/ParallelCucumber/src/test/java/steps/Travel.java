package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Travel {
	@Before
	public void start(Scenario s) {
		System.out.println("----------------Starting scenario "+ s.getName());
	}
	
	@After
	public void end(Scenario s) {
		System.out.println("---------------Ending scenario "+ s.getName());
	}
	
	@Given("I have a {string}")
	public void iHave(String mode) {
		System.out.println("I have a "+ mode);
	}
    
	@And("{string} is in good condition")
    public void condition(String vehical) {
		System.out.println(vehical + " is in good condition");
	}
    
    @When("I decide to travel")
    public void decide() {
    	System.out.println("I decide to travel");
    }
    
    @Then("I take my {string}")
    public void travel(String mode) {
    	System.out.println("I take my "+mode);
    }

}
