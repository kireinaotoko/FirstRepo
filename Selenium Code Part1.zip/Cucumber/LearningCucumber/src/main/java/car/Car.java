package car;

public class Car {
	
	public String name;
	
	public  Car() {
		System.out.println("---Constructor of Car----");
	}

}
