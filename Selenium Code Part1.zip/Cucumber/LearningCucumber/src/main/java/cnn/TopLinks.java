package cnn;

public class TopLinks {
	
	String name;
	String title;
	
	public TopLinks(String name,String title) {
		this.name=name;
		this.title=title;
	}

}
