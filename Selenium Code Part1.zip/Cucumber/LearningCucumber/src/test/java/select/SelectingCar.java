package select;

import car.Car;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Then;

public class SelectingCar {
	
	Car car;
	
	public SelectingCar(Car car) {
		System.out.println("------------------selecting car--------------");
		this.car=car;
	}
     
	
	@Then("I should get white cars in result")
	public void result() {
		System.out.println("Result "+car.name);
		car.name="XYZ";
		System.out.println("I should get white cars in result");
	}
	
	@And("cars must be atleast {int} years old")
	public void car_age(int age) {
		System.out.println("cars must be atleast "+age+" years old");
		System.out.println("Result "+car.name);
	}
	
	@But("car should not be damaged")
	public void damaged() {
		System.out.println("car should not be damaged");
	}
}
