package select;

public class User {
	
	public String hNum;
	public String street;
	public String city;
	public String country;
	
	public void printUser() {
		System.out.println(hNum+"-"+street+"-"+city+"-"+country);
	}

}
