package select;

public class Color {
	
	public String name;

}
