package buy.computer;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Computer {
	
	 @Given("I want to buy a PC")
	 public void buy_pc() {
		 System.out.println("I want to buy a PC");
	 }
	 
	 @And("^PC should be of (.*)$")
	 public void pc_company(String company) {
		 System.out.println("PC should be of "+company);
	 }
	 
	 @And("^it should be a (.*)$")
	 public void pc_type(String type) {
		 System.out.println("it should be a "+type);
	 }
	 
	 @When("^I select (.*) as (\\d+) inch$")
	 public void size(String screenType,int size) {
		 System.out.println("I select "+screenType+" as "+size+" inch");
	 }
	 
	 @And("a {string} finish")
	 public void finish(String type) {
		 System.out.println("a "+type+" finish");
	 }
	 
	 @And("I select hard drive {int} TB")
	 public void hard_drive(int capacity) {
		 System.out.println("I select hard drive "+capacity+" TB");
	 }
	 
	 @And("^Ram (\\d+) GB$")
	 public void ram(String ramSize) {
		 System.out.println("Ram "+ramSize+" GB");
	 }
	 
	 @And("^I get (.*) (\\d+) results$")
	 public void results(String range,int total) {
		 System.out.println("I get "+range+" "+total+" results");
	 }
	 
	 @Then("price should be less than {int}")
	 public void price(int price) {
		 System.out.println("Then price should be less than "+price);
	 }
	 
	 @And("it should come with a bag")
	 public void bag() {
		 System.out.println("it should come with a bag");
	 }
	 	 
	 

}
