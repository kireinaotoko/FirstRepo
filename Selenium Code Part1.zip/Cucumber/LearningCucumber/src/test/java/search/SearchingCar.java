package search;




import car.Car;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.ParameterType;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import select.Color;
import select.User;

public class SearchingCar {
	//WebDriver driver;
	
	Car car;
	
	public SearchingCar(Car car) {
		System.out.println("-------------------Searhing Car Constructor-------------");
		this.car=car;
	}
	
	
	
	@Before
	public void init(Scenario s) {
		System.out.println("-------------INIT---------------- "+ s.getName());
	}
	
	@After
	public void quit(Scenario s) {
		System.out.println("--------------QUIT---------------"+ s.getName());
	}
	
	
	@ParameterType("(.+?)")
    public Color colors(String allColors) {
	   System.out.println(allColors);
	   // connect db
	   Color c = new Color();
	   c.name = allColors.split(",")[0];
	   return c;
    }
	
	@ParameterType("(.+?)")
    public User address(String addr) {
	   System.out.println(addr);
	   User u = new User();
	   String temp[] = addr.split(",");
	   u.hNum=temp[0]; 
	   u.street=temp[1];
	   u.city=temp[2];
	   u.country=temp[3];
	   
	   return u;
	  
    }
		
	@Given("I go to buy car")
	public void buy_car() {
		//System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		//driver = new ChromeDriver();
		//System.out.println("buy_car "+driver);
		System.out.println("I go to buy car");
		car.name="Merc";
	}
	
	@And("car must be of {string}")
	public void car_make(String company) {
		System.out.println("car must be of "+company);
		//System.out.println("car_make "+driver);
		// driver.get("http://yahoo.com");
		System.out.println(car.name);
	}
	
	@And("car can be {colors} in color")
	public void car_color(Color color) {
		System.out.println("car can be "+color.name+" in color");
	}
	
	@When("I search for car")
	public void search() {
		System.out.println("I search for car");
	}
	
	@And("I select City as Tokyo")
	public void select_city() {
		System.out.println("I select City as Tokyo");
	}
	
	@And("my address is {address}")
	public void get_address(User user) {
		user.printUser();
	}
	
	
	
	
	
	
	
	
	
	
	

}
